package myclus;

import java.util.ArrayList;
import java.util.List;

import com.clus.model.Person;

public class TestData {

	public List<Person> getExpectedData() {
		List<Person> list = new ArrayList<Person>();
		list.add(new Person(111, "Rakesh", 30, "Rajbiraj"));
		list.add(new Person(222, "Amit", 40, "Kathmandu"));
		list.add(new Person(333, "Dipak", 50, "Birgunj"));
		return list;
	}

}
