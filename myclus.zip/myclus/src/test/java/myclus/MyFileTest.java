package myclus;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.clus.model.Person;
import com.clus.service.MyFile;
import com.clus.service.MyFileImpl;

public class MyFileTest extends TestData {

	@Autowired
	MyFile myFile = new MyFileImpl();

	@Test
	public void test_Csv_Transaction_File_Import() {
		List<Person> persons = myFile.readCSV();
		Assert.assertEquals(getExpectedData().size(), persons.size());
		Assert.assertEquals(getExpectedData().get(0), persons.get(0));
		Assert.assertEquals(getExpectedData().get(1), persons.get(1));
		Assert.assertEquals(getExpectedData().get(2), persons.get(2));
	}

	@Test
	public void test_xml_Transaction_File_Import() {
		List<Person> persons = myFile.readXML();
		Assert.assertEquals(getExpectedData().size(), persons.size());
		Assert.assertEquals(getExpectedData().get(0), persons.get(0));
		Assert.assertEquals(getExpectedData().get(1), persons.get(1));
		Assert.assertEquals(getExpectedData().get(2), persons.get(2));
	}

}
