package com.clus.service;

import java.util.List;

import com.clus.model.Person;

public interface MyFile {

	public List<Person> readCSV();

	public List<Person> readXML();

}
