package com.clus.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.clus.model.Person;

@Component
public class MyFileImpl implements MyFile {
	Resource csvResource = new ClassPathResource("csv_transaction.csv");
	Resource xmlResource = new ClassPathResource("employee.xml");

	public List<Person> readCSV() {
		String line = "";
		List<Person> pList = new ArrayList<Person>();
		try {
			BufferedReader bf = new BufferedReader(new InputStreamReader(csvResource.getInputStream()));
			while ((line = bf.readLine()) != null) {
				String[] data = line.split(",");
				Person p = new Person();
				p.setId(Integer.parseInt(data[0]));
				p.setName(data[1]);
				p.setAge(Integer.parseInt(data[2]));
				p.setAddress(data[3]);
				pList.add(p);
			}
			bf.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return pList;
	}

	private List<Person> getPersonDetails(Document document) {
		List<Person> persons = new ArrayList<Person>();

		@SuppressWarnings("unchecked")
		List<Node> list = document.selectNodes("/persons/person");

		for (Node personNode : list) {
			String id = personNode.valueOf("@id");
			String name = personNode.selectSingleNode("name").getText();
			String age = personNode.selectSingleNode("age").getText();
			String address = personNode.selectSingleNode("address").getText();
			persons.add(new Person(Integer.parseInt(id), name, Integer.parseInt(age), address));
		}

		return persons;
	}

	public List<Person> readXML() {
		SAXReader reader = new SAXReader();
		Document document;
		try {
			document = reader.read(xmlResource.getInputStream());
			return getPersonDetails(document);
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new ArrayList<Person>();
	}

//	public List<Person> readXML() {
//		// Get Document Builder
//		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
//		DocumentBuilder builder = null;
//		Person p = new Person();
//		// Build Document
//		Document document = null;
//		try {
//			builder = factory.newDocumentBuilder();
//		} catch (ParserConfigurationException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		try {
//			document = builder.parse(new File(xmlFilePath));
//		} catch (SAXException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		// Normalize the XML Structure; It's just too important !!
//		document.getDocumentElement().normalize();
//		// Here comes the root node
//		Element root = document.getDocumentElement();
//		System.out.println(root.getNodeName());
//		// Get all employees
//		NodeList nList = document.getElementsByTagName("employee");
//		System.out.println("============================");
//		for (int temp = 0; temp < nList.getLength(); temp++) {
//			Node node = (Node) nList.item(temp);
//			System.out.println(""); // Just a separator
//			if (((org.w3c.dom.Node) node).getNodeType() == Node.ELEMENT_NODE) {
//				// Print each employee's detail
//				Element eElement = (Element) node;
//				p.setId(Integer.parseInt(eElement.getAttribute("id")));
//				p.setName(eElement.getElementsByTagName("firstName").item(0).getTextContent());
//				p.setAge(Integer.parseInt(eElement.getElementsByTagName("age").item(0).getTextContent()));
//				p.setAddress(eElement.getElementsByTagName("address").item(0).getTextContent());
//				pList.add(p);
//
//				System.out.println("Employee id : " + eElement.getAttribute("id"));
//				System.out
//						.println("First Name : " + eElement.getElementsByTagName("firstName").item(0).getTextContent());
//				System.out.println("Last Name : " + eElement.getElementsByTagName("lastName").item(0).getTextContent());
//				System.out.println("Location : " + eElement.getElementsByTagName("location").item(0).getTextContent());
//			}
//		}
//		return pList;
//	}

}
