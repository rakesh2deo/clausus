package com.clus.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.clus.model.Person;
import com.clus.service.MyFile;


@RestController
public class MainController {
	
	  @Autowired 
	  private MyFile fs;

	@RequestMapping(value = "/csvfile", method = RequestMethod.GET)
	public List<Person> readCsv() {

		List<Person> list = fs.readCSV();
		System.out.println("CSV file read successfully.");

		return list;
	}
	
	@RequestMapping(value = "/xmlfile", method = RequestMethod.GET)
	public List<Person> readXml() {

		List<Person> list = fs.readXML();
		System.out.println("XML file read successfully.");

		return list;
	}

}
